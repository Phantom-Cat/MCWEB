# classicminecraftnet
# The source code of classic.minecraft.net
I do not own any of the textures, software, or anything here. This is rightfully owned by Microsoft Studios and Mojang Studios, and is here for modding and archivial purposes.
Minecraft Java 0.0.23a_01 for web.
# See the original working at:
https://classic.minecraft.net
# Or my reupload
https://minecraftclassic.ethpsa09.repl.co/
